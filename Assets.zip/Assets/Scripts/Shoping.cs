using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Shoping : MonoBehaviour
{
    private bool interact = false;
    private bool ShopingStatus = false;
    // -------------------------------------------------------Start-------------------------------------------------------
    void Start()
    {

    }
    // -------------------------------------------------------Update-------------------------------------------------------
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            interact = true;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            interact = false;
        }
    }
}
