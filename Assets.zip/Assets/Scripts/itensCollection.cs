using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItensCollection : MonoBehaviour
{
   
    // [SerializeField] mostar e edita variáveis privadas no Inspector do Unity
    [SerializeField] private int Plastico = 0; // Serializa o campo plastico e mostra a quantidade de cada item coletado 
    [SerializeField] private int Ferro = 0; // Serializa o campo ferro e mostra a quantidade de cada item coletado
    [SerializeField] private int Madeira = 0; // Serializa o campo madeira e mostra a quantidade de cada item coletado


    // Função chamada quando outro colisor entra no colisor associado a este objeto (um gatilho)
    private void OnTriggerEnter(Collider objeto)
    {
        // Verifica se o objeto colidido tem a tag "Madeira,Plastico e Ferro"
        if(objeto.gameObject.tag == "madeira" || objeto.gameObject.tag == "plastico" || objeto.gameObject.tag == "ferro")
        {
            // Destroi o objeto colidido após um pequeno atraso (0.1 segundos)
            Destroy(objeto.gameObject, 0.1f);
          
        }
         // Verifica se o objeto colidido tem a tag "Madeira"
        if(objeto.gameObject.tag == "madeira")
        {
          Madeira++; // incrementa a variavel Madeira
          Debug.Log("vc coletou madeira QTD:" +Madeira);
          
        }
         // Verifica se o objeto colidido tem a tag "Plastico "
        else if(objeto.gameObject.tag == "plastico")
        {
           Plastico++; // incrementa a variavel Plastico
           Debug.Log("vc coletou plastico QTD:" +Plastico);
        }
         // Verifica se o objeto colidido tem a tag "Ferro"
        else if(objeto.gameObject.tag == "ferro")
        {
            Ferro++; // incrementa a variavel Ferro
            Debug.Log("vc coletou ferro QTD:" +Ferro);
        }
    }
 }